"""Current version of package pybwtool"""
__version__ = "1.0.1"